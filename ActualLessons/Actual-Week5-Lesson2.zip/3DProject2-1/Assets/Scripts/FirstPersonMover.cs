﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonMover : MonoBehaviour 
{
    public float movementSpeed = 10.0f;
    public float rotationSpeed = 100.0f;

	// Update is called once per frame
	void Update() 
    {
        if( Input.GetKey( KeyCode.UpArrow ) )
        {
            transform.position += transform.forward * movementSpeed * Time.deltaTime;
        }

        if( Input.GetKey( KeyCode.DownArrow ) )
        {
            transform.position += -transform.forward * movementSpeed * Time.deltaTime;
        }

        transform.Rotate( 0.0f, Input.GetAxis( "Horizontal" ) * rotationSpeed * Time.deltaTime, 0.0f );
	}
}
