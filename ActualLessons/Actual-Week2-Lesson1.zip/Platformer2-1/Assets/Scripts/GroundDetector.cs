﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundDetector : MonoBehaviour 
{
    public bool isOnGround
    {
        protected set;
        get;
    }

    public void Start()
    {
        isOnGround = false;
    }

    public void OnCollisionEnter2D( Collision2D collision )
    {
        if( collision.collider.gameObject.layer == 8 )
        {
            isOnGround = true;
            Debug.Log( "OnCollisionEnter" );
        }
    }

    public void OnCollisionExit2D( Collision2D collision )
    {
        if( collision.collider.gameObject.layer == 8 )
        {
            isOnGround = false;
            Debug.Log( "OnCollisionExit" );
        }
    }
}
