﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour 
{	
    public Mover controlledMover;

	// Update is called once per frame
	void Update () 
    {
        if( Input.GetKey( KeyCode.RightArrow ) )
        {
            controlledMover.AccelerateInDirection( Vector2.right );
        }

        if( Input.GetKey( KeyCode.LeftArrow ) )
        {
            controlledMover.AccelerateInDirection( Vector2.left );
        }

        if( Input.GetKey( KeyCode.Space ) )
        {
            controlledMover.GetComponent<Jumper>().Jump();
        }
	}
}
