﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatrolController : MonoBehaviour 
{
    public Mover controllerMover;

    public float patrolTime = 1.0f;

    private float remainingPatrolTime;

    private float movementDirection;

    public bool jumpsAtEnd = false;

	// Use this for initialization
	void Start () {
        remainingPatrolTime = patrolTime;
        movementDirection = 1.0f;
	}
	
	// Update is called once per frame
	void Update () 
    {
        remainingPatrolTime -= Time.deltaTime;
        if( remainingPatrolTime > 0.0f )
        {
            controllerMover.AccelerateInDirection( new Vector2( movementDirection, 0.0f ) );
        } 
        else if( !controllerMover.IsWalking() )
        {
            movementDirection *= -1;
            remainingPatrolTime = patrolTime;

            if( jumpsAtEnd )
            {
                Jumper jumper = controllerMover.GetComponent< Jumper >();
                if( jumper != null )
                {
                    jumper.Jump();
                }
            }
        }
	}
}
