﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour 
{
    public GameObject[] spawnedPrefabs;

    public bool parentToThis = true;

    public Transform spawnTarget;

    protected virtual GameObject GetNextPrefab()
    {
        int randomIndex = Random.Range( 0, spawnedPrefabs.Length );
        return spawnedPrefabs[ randomIndex ];
    }

    public virtual GameObject Spawn()
    {
        GameObject prefab = GetNextPrefab();
        GameObject obj = Instantiate< GameObject >( prefab );
        obj.transform.parent = parentToThis ? transform : transform.parent;
        obj.transform.position = spawnTarget != null ? spawnTarget.position : transform.position;

        return obj;
    }
}
