﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RunnerController : MonoBehaviour 
{
    public Mover controlledMover;

    public Vector2 targetDirection;
	
	// Update is called once per frame
	void Update () 
    {
        controlledMover.AccelerateInDirection( targetDirection );
	}
}
