﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuoyancyForceApplier : MonoBehaviour 
{
    public float buoyancyGravityMultiple = 1.2f;
    public float waterFrictionAmount = 0.1f;

    protected List<Rigidbody> floatingBodies;

	void Awake () 
    {
        floatingBodies = new List<Rigidbody>();
	}
	
    public void OnTriggerEnter( Collider other )
    {
        Rigidbody rb = other.GetComponent<Rigidbody>();
        if( rb != null && !floatingBodies.Contains( rb ) )
        {
            floatingBodies.Add( rb );
        }
    }

    public void OnTriggerExit( Collider other )
    {
        Rigidbody rb = other.GetComponent<Rigidbody>();
        if( rb != null )
        {
            floatingBodies.Remove( rb );
        }
    }

	// Update is called once per frame
	void FixedUpdate () 
    {
        Vector3 buoyancyVelocity = Physics.gravity * -buoyancyGravityMultiple;
        for( int bodyIndex = 0; bodyIndex < floatingBodies.Count; bodyIndex++ )
        {
            Rigidbody rb = floatingBodies[ bodyIndex ];
            rb.AddForce( buoyancyVelocity * rb.mass );

            float friction = ( 1.0f - waterFrictionAmount * Time.fixedDeltaTime );

            Vector3 vel = rb.velocity;
            float initialVelY = vel.y;

            vel = rb.velocity * friction;
            if( initialVelY > 0.0f )
            {
                vel.y = initialVelY;
            }

            rb.velocity = vel;
        }
	}
}
