﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class MovementAnimatorUpdater : MonoBehaviour 
{
    public float walkingSpeedThreshold = 0.3f;
    protected Animator animator;
    protected NavMeshAgent agent;
    protected Rigidbody body;

	void Awake() 
    {
        animator = GetComponent< Animator >();
        agent = GetComponent<NavMeshAgent>();
        body = GetComponent< Rigidbody >();
	}
	
	// Update is called once per frame
	void Update () 
    {
        animator.SetBool( "isMoving", ( agent.velocity.sqrMagnitude >= walkingSpeedThreshold * walkingSpeedThreshold ) );
        animator.SetFloat( "speed", agent.velocity.sqrMagnitude / ( agent.speed * agent.speed ) );
        animator.SetBool( "isJumping", agent.isOnOffMeshLink || !body.isKinematic );
	}
}
