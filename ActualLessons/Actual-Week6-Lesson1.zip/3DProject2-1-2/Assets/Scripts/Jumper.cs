﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Jumper : MonoBehaviour 
{
    public float jumpImpulse = 10.0f;

    protected Rigidbody body;
    protected NavMeshAgent agent;

    public void Awake()
    {
        body = GetComponent< Rigidbody >();
        agent = GetComponent<NavMeshAgent>();
    }

    public void Jump()
    {
        body.isKinematic = false;
        body.velocity = agent.velocity * 2;
        agent.enabled = false;
        body.AddForce( Vector3.up * jumpImpulse );
    }
	
	// Update is called once per frame
	void Update () 
    {
        if( Input.GetKeyDown( KeyCode.Space ) && agent.enabled )
        {
            Jump();
        }
	}

    public void OnCollisionEnter( Collision other )
    {
        if( other.collider.gameObject == Terrain.activeTerrain.gameObject )
        {
            agent.enabled = true;
            agent.velocity = body.velocity;
            body.isKinematic = true;
        }
    }
}
