﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DistanceSpawner : Spawner 
{
    public Transform target;

    public Rect spawnRange;

    public float distanceRequiredToSpawn;

    public bool useDistanceFromSpawnTarget;

    public float minY;

    public float maxY;

    protected Vector3 lastSpawnPosition;

	// Use this for initialization
	void Start () 
    {
        if( target != null )
        {
            lastSpawnPosition = target.position;
        }
		
	}
	
	// Update is called once per frame
	void Update () 
    {
        if( target == null )
        {
            return;
        }

        Vector3 targetPosition = target.position;
        if( useDistanceFromSpawnTarget )
        {
            if( Mathf.Abs( targetPosition.x - spawnTarget.transform.position.x ) <= distanceRequiredToSpawn )
            {
                Spawn();
            }
        } 
        else
        {
            float distance = Vector3.Distance( targetPosition, lastSpawnPosition );
            if( distance >= distanceRequiredToSpawn )
            {
                Spawn();
            }
        }
	}

    public override GameObject Spawn()
    {
        GameObject spawnedObj = base.Spawn();
        float spawnRangeX = spawnRange.x + Random.Range( 0.0f, spawnRange.width );
        float spawnRangeY = spawnRange.y + Random.Range( 0.0f, spawnRange.height );

        Vector3 newPosition = spawnedObj.transform.position + new Vector3( spawnRangeX, spawnRangeY, 0 );

        newPosition.y = Mathf.Clamp( newPosition.y, minY, maxY );
        spawnedObj.transform.position = newPosition;

        spawnTarget = spawnedObj.transform;
        if( target != null )
        {
            lastSpawnPosition = target.position;
        }

        return spawnedObj;
    }
}
