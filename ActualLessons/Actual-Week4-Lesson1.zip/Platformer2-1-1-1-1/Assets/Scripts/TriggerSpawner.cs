﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerSpawner : Spawner 
{
    public LayerMask triggerMask;

    public void OnTriggerEnter2D( Collider2D collider )
    {
        if( ( ( 1 << collider.gameObject.layer ) & triggerMask ) != 0 )
        {
            Spawn();
        }
    }
}
