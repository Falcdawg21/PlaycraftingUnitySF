﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destructor : MonoBehaviour {

    public int damageAmount = 1;

    public Destructible destructible;

//    public void OnCollisionEnter2D( Collision2D collision )
//    {
//        Destructible hitDestructible = collision.collider.GetComponent< Destructible >();
//
//        if( hitDestructible != null )
//        {
//            hitDestructible.TakeDamage( damageAmount );
//        }
//    }

    public virtual void DoDamage( Destructible dest )
    {
        if( ( ( 1 << this.gameObject.layer ) ^ dest.dontTakeDamageFromLayer.value ) == 0 )
        {
            return;

        }

        dest.TakeDamage( damageAmount );
    }

}
