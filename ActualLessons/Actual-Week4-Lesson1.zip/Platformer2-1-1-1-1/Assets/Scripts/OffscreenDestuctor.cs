﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OffscreenDestuctor : Destructor 
{
    public float xDifferenceFromCameraForDestruction;

	// Update is called once per frame
	void Update () 
    {
        if( Mathf.Abs( Camera.main.transform.position.x - destructible.transform.position.x ) 
            >= xDifferenceFromCameraForDestruction )
        {
            DoDamage( destructible );
        }
	}
}
